# Share-Files-Via-Bluetooth-Android-App
Simple android app that can search Bluetooth device enabled around you. you can see a list of previous paired device and can also send files to any Bluetooth device.
